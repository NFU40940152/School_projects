
namespace WinFormsApp1
{
    public partial class Form1 : Form
    {

        int count;
        int order=0;
        int year;
        int maximum = 2022;
        int minimum = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = " ";
            label3.Text = " ";
            label2.Text = " ";
            label4.Text = " ";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = "(�@�~�ԭz)";
            
            this.pictureBox1.Image = Image.FromFile(Application.StartupPath + "\\pictures\\topic1.jpg");
            count = 0;
            maximum = 2022;
            minimum = 1;
            label1.Text = " ";
            label2.Text = minimum.ToString() + "��" + maximum.ToString();
            label3.Text = " ";
            year = 1872;
            order = 1;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((int)e.KeyChar < 48 | (int)e.KeyChar > 57) & (int)e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (order == 0)
            {
                MessageBox.Show("�Х�����D��");
                return;
            }
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("�п�J�~��");
                return;
            }
            string s = textBox1.Text;
           int keyin =int.Parse(s);
            if (keyin >= minimum && keyin < maximum && order == 1)
            {
                count += 1;

                label2.Text = minimum.ToString() + "��" + maximum.ToString();
                if (keyin == year)
                {
                    label1.Text = "���T����";
                    label3.Text = "�q�F" + count.ToString() + "��";
                    order = 0;
                }
                else if (keyin > year)
                {
                    maximum = keyin;
                    label2.Text = minimum.ToString() + "��" + maximum.ToString();
                    label1.Text = "��C";
                }
                else if (keyin < year)
                {
                    minimum = keyin;
                    label2.Text = minimum.ToString() + "��" +maximum.ToString();
                    label1.Text = "��";
                }               
            }
            else
            {
                label1.Text = "�W�X�d��";
            }
        }

    }
}